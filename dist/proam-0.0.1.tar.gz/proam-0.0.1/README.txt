Process photos to send to ProAm (http://proamimaging.com).
